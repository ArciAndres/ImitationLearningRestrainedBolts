# -*- coding: utf-8 -*-

__title__ = 'gym_breakout_pygame'
__description__ = 'Gym Breakout environment using Pygame'
__url__ = 'https://github.com/whitemech/gym-breakout-pygame.git'
__version__ = '0.1.1'
__author__ = 'Marco Favorito, Luca Iocchi'
__author_email__ = 'favorito@diag.uniroma1.it, iocchi@diag.uniroma1.it'
__license__ = 'Apache License 2.0'
__copyright__ = '2019 Marco Favorito, Luca Iocchi'
