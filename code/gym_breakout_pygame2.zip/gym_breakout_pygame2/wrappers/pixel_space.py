# -*- coding: utf-8 -*-

"""Breakout environments using a matrix of pixels as state space."""

# TODO
